import json
import boto3
import os
from datetime import datetime
from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

s3 = boto3.client('s3')
rekognition = boto3.client('rekognition')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])

def handler(event, context):
    try:
        print("Received event:", json.dumps(event))
        
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']
        
        print(f"Processing image from bucket: {bucket}, key: {key}")
        
        # Extract imageId from key
        image_id = key.split('/')[-1]
        
        # Get image analysis
        labels = detect_labels(bucket, key)
        text = detect_text(bucket, key)
        
        print(f"Detected labels: {json.dumps(labels, cls=DecimalEncoder)}")
        print(f"Detected text: {json.dumps(text)}")
        
        # Store result in DynamoDB
        item = {
            'imageId': image_id,
            'uploadDate': datetime.utcnow().isoformat(),
            'status': 'processed',
            'url': key,  # Store only the key
            'aiAnalysis': {
                'labels': labels,
                'text': text
            },
            'searchableTerms': 'adult'  # We're focusing on 'adult' search for now
        }
        
        print(f"Storing item in DynamoDB: {json.dumps(item, cls=DecimalEncoder)}")
        table.put_item(Item=item)
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Image processed successfully'}, cls=DecimalEncoder)
        }
        
    except Exception as e:
        print(f"Error processing image: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def detect_labels(bucket, key):
    print(f"Detecting labels for {bucket}/{key}")
    response = rekognition.detect_labels(
        Image={'S3Object': {'Bucket': bucket, 'Name': key}},
        MaxLabels=10,
        MinConfidence=70
    )
    return [{
        'name': label['Name'],
        'confidence': Decimal(str(label['Confidence']))
    } for label in response['Labels']]

def detect_text(bucket, key):
    print(f"Detecting text for {bucket}/{key}")
    response = rekognition.detect_text(
        Image={'S3Object': {'Bucket': bucket, 'Name': key}}
    )
    return [text['DetectedText'] for text in response['TextDetections'] 
            if text['Type'] == 'WORD']