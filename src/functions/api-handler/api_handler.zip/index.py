import json
import boto3
import os
from datetime import datetime
import uuid
from boto3.dynamodb.conditions import Attr

# Initialize AWS Clients
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])

# Construct S3 URL
def get_image_url(bucket, key):
    return f"https://{bucket}.s3.{os.environ['AWS_REGION']}.amazonaws.com/{key}"

def handler(event, context):
    """Main API handler for image upload, retrieval, and search."""
    print("\U0001F4E5 Received API Event:", json.dumps(event, indent=2))

    http_method = event.get('httpMethod')
    path = event.get('path', '')

    if http_method == 'POST' and path.endswith('/images'):
        return handle_upload_request()
    elif http_method == 'GET' and '/images/' in path:
        image_id = event.get('pathParameters', {}).get('imageId')
        return get_image_metadata(image_id)
    elif http_method == 'GET' and '/search' in path:
        query = event.get('queryStringParameters', {}).get('q', '').lower().strip()
        return search_images(query)

    return {
        'statusCode': 400,
        'headers': {'Access-Control-Allow-Origin': '*'},
        'body': json.dumps({'error': 'Invalid request'})
    }

def handle_upload_request():
    """Handles image upload request and returns a pre-signed URL."""
    try:
        image_id = str(uuid.uuid4())
        key = f"uploads/{image_id}"
        upload_url = s3.generate_presigned_url(
            'put_object',
            Params={'Bucket': os.environ['S3_BUCKET'], 'Key': key, 'ContentType': 'image/jpeg'},
            ExpiresIn=3600
        )

        # Store metadata in DynamoDB with 'pending' status
        table.put_item(Item={
            'imageId': image_id,
            'uploadDate': datetime.utcnow().isoformat(),
            'status': 'pending',
            'url': key  # Store only the key, not the full URL
        })

        print(f"✅ Stored pending image metadata: {image_id}")

        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'imageId': image_id,
                'uploadUrl': upload_url,
                'status': 'pending'
            })
        }
    except Exception as e:
        print(f"\U0001F6A8 Error in handle_upload_request: {str(e)}")
        return error_response(str(e))

def get_image_metadata(image_id):
    """Retrieve metadata of an uploaded image from DynamoDB."""
    try:
        print(f"🔍 Fetching metadata for imageId: {image_id}")

        response = table.get_item(Key={'imageId': image_id})
        if 'Item' not in response:
            return error_response('Image not found', 404)

        item = response['Item']
        item['url'] = get_image_url(os.environ['S3_BUCKET'], item['url'])

        print(f"✅ Found image metadata: {json.dumps(item, indent=2)}")

        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps(item)
        }
    except Exception as e:
        print(f"\U0001F6A8 Error in get_image_metadata: {str(e)}")
        return error_response(str(e))

def search_images(query):
    """Search for images in DynamoDB based on partial matches in searchableTerms."""
    try:
        print(f"🔍 Searching for images with term: '{query}'")

        # Use Scan instead of Query to allow partial matching
        response = table.scan(
            FilterExpression=Attr('searchableTerms').contains(query)
        )

        items = response.get('Items', [])
        if not items:
            print(f"⚠ No results found for query: {query}")

        # Convert S3 keys into full URLs
        for item in items:
            item['url'] = get_image_url(os.environ['S3_BUCKET'], item['url'])

        print(f"✅ Search Results: {json.dumps(items, indent=2)}")

        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'images': items})
        }
    except Exception as e:
        print(f"\U0001F6A8 Error in search_images: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': str(e)})
        }

def error_response(message, status_code=500):
    """Generate an error response with proper headers."""
    return {
        'statusCode': status_code,
        'headers': {'Access-Control-Allow-Origin': '*'},
        'body': json.dumps({'error': message})
    }